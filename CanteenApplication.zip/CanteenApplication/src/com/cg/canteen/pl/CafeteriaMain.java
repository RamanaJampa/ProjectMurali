package com.cg.canteen.pl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.exception.CafeteriaException;
import com.cg.canteen.service.CafeteriaService;
import com.cg.canteen.service.CafeteriaServiceImpl;

public class CafeteriaMain {
	
	static Scanner scanner = new Scanner(System.in);
	static CafeteriaService cafeteriaService = null;
	static CafeteriaServiceImpl cafeteriaServiceImpl = null;
	
	public static void main(String[] args) throws CafeteriaException {
		
		CafeteriaBean bean = null;
		String foodId = null;
		 int option = 0;
		 
		 while(true)
		 {
			 	System.out.println();
				System.out.println();
				System.out.println("     Cafe Agape  CAPGEMINI    \n");
				System.out.println("1.Add Item");
				System.out.println("2.View Item");
				System.out.println("3.Retrieve All");
				System.out.println("4.Exit");
				System.out.println("__________________________________");
				System.out.println("Select An Option:");
			 
				try
				{
					option = scanner.nextInt();
					switch(option)
					{
					case 1:
							while(bean == null)
							{
								bean = populateCafeteriaBean();
							}
							try
							{
								cafeteriaService = new CafeteriaServiceImpl();
							foodId = cafeteriaService.addItem(bean);
							System.out.println("Food Items has been successfully Added");
							System.out.println("Food Id is:"+foodId);
							}finally{
								foodId = null;
								cafeteriaService = null;
								bean = null;
							//	option = 0;
							}
			
							
							break;
					case 2:
							
								try
								{
									cafeteriaService = new CafeteriaServiceImpl();
									System.out.println("Enter Your foodId");
									String a=scanner.next();
									cafeteriaService.viewItem(a);
								}
							catch(Exception e)
								{
									e.printStackTrace();
								}
						
							break;
					case 3:
						

						cafeteriaService = new CafeteriaServiceImpl();
						List<CafeteriaBean> foodList = new ArrayList<CafeteriaBean>();
						foodList = cafeteriaService.retrieveAll();

						if (foodList != null) {
							Iterator<CafeteriaBean> i = foodList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

						break;

						
					case 4:

						System.out.print("Exit Trust Application");
						System.exit(0);
						break;
					default:
						
						System.out.println("Enter a valid option[1-4]");
						break;

					}
					}catch(Exception e)
					{
						e.printStackTrace();
						System.err.println(e);
					}
		 	}
}

	private static CafeteriaBean populateCafeteriaBean() {
		
		CafeteriaBean bean = new CafeteriaBean();
		System.out.println("\nEnter Details");
		
		
		System.out.println("Enter the food Price");
		bean.setFoodprice(scanner.nextFloat());
		
		System.out.println("Enter food Quantity:");
		bean.setFoodQuantity(scanner.nextInt());
		
		System.out.println("Enter Food Item");
		bean.setFoodItem(scanner.next());
		cafeteriaServiceImpl = new CafeteriaServiceImpl();
		try 
		{
			cafeteriaServiceImpl.validateItem(bean);
			return bean;
		}catch(CafeteriaException cafeteriaException)
		{
			System.err.println("Invalid data");
			System.err.println(cafeteriaException.getMessage()+"\n Try Again..");
		}
		return null;
		
	}
			 	
	}
