package com.cg.canteen.exception;

public class CafeteriaException extends Exception{

	public CafeteriaException(String message) {
		super(message);
	}


}
