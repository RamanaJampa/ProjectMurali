package com.cg.canteen.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.exception.CafeteriaException;
import com.cg.canteen.util.DBConnection;

public class CafeteriaDAOImpl implements CafeteriaDAO{
	
	

	@Override
	public String addItem(CafeteriaBean bean) throws IOException {
		Connection connection = DBConnection.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String foodId=null;

		try
		{
			preparedStatement = connection.prepareStatement(QueryMapper.Add_Details);
			preparedStatement.setFloat(1,(Float) bean.getFoodPrice());
			preparedStatement.setInt(2,bean.getFoodQuantity());
			preparedStatement.setString(3,bean.getFoodItem());
			
			preparedStatement.executeUpdate();
			Statement st = connection.createStatement();
			resultSet = st.executeQuery(QueryMapper.View_Details);
			if(resultSet.next())
			{
				foodId=resultSet.getString(1);
			}
			
		return foodId;
		}catch(SQLException sqle)
		{
			sqle.printStackTrace();
			System.out.println(sqle);
		}
		
		return null;
	}
	
	

	@Override
	public CafeteriaBean viewItem(String foodId) throws IOException {
		
		Connection connection = DBConnection.getConnection();
		String a = foodId;
		try {
			PreparedStatement ps = connection.prepareStatement(QueryMapper.View_Details_By_Id);
			ps.setString(1,a);
			
			ResultSet rs = ps.executeQuery();
					while(rs.next())
					{
						System.out.println("Food Id Is :"+rs.getString(1));
						System.out.println("Food Price :"+rs.getFloat(2));
						System.out.println("Food Quantity :"+rs.getString(3));
						System.out.println("Orderdate :"+rs.getString(4));
						System.out.println("food Item :"+rs.getString(5));
						float foodPrice = rs.getFloat(2);
						int foodQuantity = rs.getInt(3);
						float totalBill = foodPrice*foodQuantity;
						
						System.out.println("Total bill is:"+totalBill);
					}
		}catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		return null;
		
	}
	
	
	

	@Override
	public List<CafeteriaBean> retrieveAll() throws IOException {

		Connection con=DBConnection.getConnection();
		int itemCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CafeteriaBean> foodList = new ArrayList<CafeteriaBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.View_All_Details);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CafeteriaBean bean=new CafeteriaBean();
				bean.setFoodId(resultset.getString(1));
				bean.setFoodprice(resultset.getFloat(2));
				bean.setFoodQuantity(resultset.getInt(3));
				bean.setOrderDate(resultset.getDate(4));
				bean.setFoodItem(resultset.getString(5));
				foodList.add(bean);
				
				itemCount++;
			}			
			
		} catch (SQLException sqlException) {
			System.err.println(sqlException);
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				System.err.println(e);
			}
		}
		
		if( itemCount == 0)
			return null;
		else
			return foodList;
	}


}
