package com.cg.canteen.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CafeteriaDAOImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
