package com.cg.canteen.dao;

import java.io.IOException;
import java.util.List;

import com.cg.canteen.bean.CafeteriaBean;

public interface CafeteriaDAO {
	
	public String addItem(CafeteriaBean bean) throws IOException;
	public CafeteriaBean viewItem(String foodId) throws IOException;
	public List retrieveAll() throws IOException;

	
}
